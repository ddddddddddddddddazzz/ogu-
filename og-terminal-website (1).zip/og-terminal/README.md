# OG Terminal

Terminal-themed username discovery website. Generates up to 500 short usernames per batch instantly on the client and offers conservative public profile lookups.

## Run locally

Requires Node.js 18+.

```bash
npm start
```

Open http://localhost:3000

## Deploy

Deploy this repository to a Node.js host such as Render or Railway. Use **Build Command** `npm install`, **Start Command** `npm start`; the platform sets `PORT`. Or deploy as a Node web service on any VM.

## Platform support

- **GitHub, Reddit**: sequential server-side public profile checks. `TAKEN` means public profile exists; `NOT FOUND` means public profile not found, **not** guaranteed signup availability.
- **TikTok, Instagram, X**: local generation plus profile links. Results are `UNVERIFIED`, because public profile URLs are not authoritative availability APIs.

Rate limits: The backend enforces at most one request per client and platform approximately every 1.25 seconds. The browser adds pacing too. HTTP 403/429/network errors are classified `UNVERIFIED`, never `AVAILABLE`. Do not increase request rates without an authorized platform API and compliance review. This project does not promise unlimited real-time checks.

## Security / design

No dependencies or account credentials. Username syntax validated, input encoded, escaped UI via DOM APIs, conservative CSP. This is a starter project, not an abuse-resistant public SaaS (for that, add reverse-proxy rate limiting, observability, server-side queues and authentication).
