const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const PORT = Number(process.env.PORT) || 3000;
const ROOT = path.join(__dirname, 'public');
const last = new Map();
const LIMIT_MS = 1250; // per client/platform: make scanning deliberately conservative
const platforms = {
  github: { url: n => `https://github.com/${n}`, pattern: /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,37}[a-zA-Z0-9])?$/, check: true },
  reddit: { url: n => `https://www.reddit.com/user/${n}/`, pattern: /^[a-zA-Z0-9_-]{3,20}$/, check: true },
  tiktok: { url: n => `https://www.tiktok.com/@${n}`, pattern: /^[a-zA-Z0-9._]{2,24}$/, check: false },
  instagram: { url: n => `https://www.instagram.com/${n}/`, pattern: /^[a-zA-Z0-9._]{1,30}$/, check: false },
  x: { url: n => `https://x.com/${n}`, pattern: /^[a-zA-Z0-9_]{1,15}$/, check: false }
};
function json(res, status, data) { res.writeHead(status, {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}); res.end(JSON.stringify(data)); }
async function check(platform, username) {
  const config = platforms[platform], profile = config.url(username);
  if (!config.pattern.test(username)) return {username, platform, status:'invalid', profile};
  if (!config.check) return {username, platform, status:'unverified', profile, detail:'No reliable public availability API; verify on the platform.'};
  try {
    const url = platform === 'github' ? `https://api.github.com/users/${encodeURIComponent(username)}` : `https://www.reddit.com/user/${encodeURIComponent(username)}/about.json`;
    const response = await fetch(url, {headers: {'user-agent':'OGTerminal/1.0 (personal username research)','accept': 'application/json'}, signal: AbortSignal.timeout(6500), redirect:'follow'});
    if (response.status === 200) return {username,platform,status:'taken',profile};
    if (response.status === 404) {
      // A missing public profile does NOT guarantee signup eligibility.
      return {username,platform,status:'not-found',profile,detail:'No public profile found. Signup availability is not guaranteed.'};
    }
    return {username,platform,status:'unverified',profile,detail:`Platform returned HTTP ${response.status}; no availability conclusion.`};
  } catch(e) { return {username,platform,status:'unverified',profile,detail:'Network request failed or timed out.'}; }
}
const server = http.createServer(async (req,res) => {
  const u = new URL(req.url, `http://${req.headers.host||'localhost'}`);
  if (u.pathname === '/api/check' && req.method === 'GET') {
    const platform = u.searchParams.get('platform') || '';
    const username = u.searchParams.get('username') || '';
    if (!platforms[platform] || username.length > 40) return json(res,400,{error:'Invalid platform or username.'});
    const ip = (req.socket.remoteAddress || 'unknown').slice(0,80);
    const key = `${ip}:${platform}`;
    const now = Date.now();
    if (now - (last.get(key)||0) < LIMIT_MS) return json(res,429,{error:'Rate limit: one request per platform approximately every 1.25 seconds.'});
    last.set(key,now);
    return json(res,200,await check(platform,username));
  }
  if (req.method !== 'GET' || !['/','/index.html'].includes(u.pathname)) return json(res,404,{error:'Not found'});
  fs.readFile(path.join(ROOT,'index.html'),(err,data)=>{if(err) return json(res,500,{error:'Unable to load page'});res.writeHead(200,{'content-type':'text/html; charset=utf-8','x-content-type-options':'nosniff','content-security-policy':"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'"});res.end(data)});
});
server.listen(PORT, '0.0.0.0',()=>console.log(`OG Terminal running at http://localhost:${PORT}`));
